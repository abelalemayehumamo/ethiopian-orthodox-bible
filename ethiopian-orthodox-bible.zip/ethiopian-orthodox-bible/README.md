# Ethiopian Orthodox Bible — መጽሐፍ ቅዱስ

Offline-first Ethiopian Orthodox Tewahedo Bible reader for Android.
React Native 0.75 + TypeScript + SQLite (FTS5 search).

## Status: architecture + app shell complete, Bible text NOT yet included

This is a real, runnable app skeleton — navigation, database layer, all
screens, Amharic UI, theming, bookmarks/history/settings — but it ships with
**zero verses**. See `docs/BIBLE_DATA.md` for exactly why, and exactly what
you need to supply. Every screen degrades gracefully (Amharic empty-state
messages) until real data is imported; nothing crashes on missing data.

## Quick start

```
npm install
npm run env-check
npm run android
```
Full instructions from a bare machine: `docs/SETUP.md`.

## Import your Bible data

```
npm run import-bible -- --input your-source.csv --format csv --out data/raw/bible.json
npm run validate-bible -- --input data/raw/bible.json
npm run build-bible-db -- --input data/raw/bible.json
```

## Docs

| File | Covers |
|---|---|
| `docs/BIBLE_DATA.md` | Legal status, required format, import pipeline |
| `docs/ARCHITECTURE.md` | App structure, navigation, state, search strategy |
| `docs/DATABASE.md` | Every table, why two databases, migrations |
| `docs/SETUP.md` | Fresh-machine dev environment, all commands |
| `docs/BUILD.md` | Debug/release APK & AAB |
| `docs/SIGNING.md` | Keystore creation and Gradle signing config |
| `docs/PLAY_STORE.md` | Submission checklist |
| `docs/TESTING.md` | What's actually been verified vs. what you must check |
| `docs/LICENSES.md` | Code/data/asset licensing notes |

## Project structure

```
ethiopian-orthodox-bible/
├── android/                 Android project (Gradle, manifest)
├── src/
│   ├── components/          Header, NavigationDrawer, BookCard, ChapterCell, VerseItem, SettingRow
│   ├── screens/              Home, Testament, BookList, ChapterGrid, Reader, Search, Bookmarks, History, Settings, About
│   ├── navigation/            Drawer + stack wiring, route types
│   ├── database/              schema.sql, BibleDatabase.ts, BibleRepository.ts
│   ├── services/               BookmarkService, HistoryService, SettingsService
│   ├── context/                 ThemeContext
│   ├── theme/                    Original burgundy/gold/parchment design tokens
│   ├── types/                     Shared TypeScript types
│   └── data/canon.json             81-book canon scaffold (see BIBLE_DATA.md)
├── scripts/
│   ├── import-bible/          csv/txt → canonical JSON
│   ├── validate-bible/         integrity checks, PASS/FAIL report (tested — see docs/TESTING.md)
│   └── build-database/          canonical JSON → bible.db
├── docs/
└── tests/
```

## Known limitations (read before assuming anything is finished)

- No Bible text is bundled (by design — see above).
- 3 of the 81 canonical books' chapter counts are marked `verified: false`
  or `null` pending confirmation against an authoritative EOTC source
  (see `_placeholder_note` in `src/data/canon.json`); several
  Ethiopian-canon-unique books (Enoch, Jubilees, Meqabyan, etc.) aren't in
  the list yet at all.
- Nothing here has been through an actual Android build/emulator run — this
  was built in a sandbox without the Android SDK. `scripts/validate-bible`
  is the one piece that was actually executed and confirmed correct.
- No automated UI tests yet, only the structural unit-test starting point in
  `tests/unit/`.
- App icon / adaptive icon / splash screen art are not yet created (Sections
  8, 26, 40 of the original brief) — placeholder Android defaults are in use.

## Free browser-only APK build (no local setup)

`.github/workflows/build-apk.yml` builds a debug APK on GitHub's free
Actions runners — no Android SDK, no payment, works from a phone browser.
See the assistant's step-by-step in-chat instructions, or `docs/TROUBLESHOOTING.md`
for what the workflow actually does.
