# Add project-specific ProGuard rules here.
# react-native-sqlite-storage and react-navigation generally work with default RN rules;
# if you see a runtime ClassNotFoundException in a release build, add a -keep rule for that class.
-keep class com.facebook.hermes.unicode.** { *; }
-keep class com.facebook.jni.** { *; }
