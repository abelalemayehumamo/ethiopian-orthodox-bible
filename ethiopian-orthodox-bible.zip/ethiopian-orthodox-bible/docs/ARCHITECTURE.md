# Architecture

React Native 0.75 + TypeScript, offline-first, no backend server.

```
UI (screens/components)
        │
        ▼
services (BookmarkService, HistoryService, SettingsService)
database (BibleRepository)
        │
        ▼
BibleDatabase.ts  →  bible.db (read-only, bundled)  +  user.db (read/write, runtime)
```

- **Navigation**: `@react-navigation` drawer (hamburger menu) wrapping a
  native-stack navigator for the actual screens. Back-button behavior is the
  stack default (pops), which matches Android platform conventions.
- **State**: local component state + a single `ThemeContext`. No Redux/MMKV —
  the data lives in SQLite already, so a separate client-state store would
  just be a second source of truth. `useFocusEffect` re-reads from SQLite
  when a screen regains focus (e.g. after bookmarking a verse) instead of
  keeping a parallel in-memory cache.
- **Search**: SQLite FTS5, see `docs/DATABASE.md`.
- **Theme**: `src/theme/theme.ts` defines an original burgundy/gold/parchment
  palette (see section 15 of the brief) with light/dark variants; no
  copyrighted assets referenced.
- **Why React Native over native Kotlin**: the brief's own stack preference,
  it lets one codebase support both API surfaces the app touches (SQLite +
  standard RN UI), and it's faster to iterate on the Amharic-heavy UI text
  without touching XML layouts per screen. A native Kotlin/Jetpack Compose
  rewrite is possible later without changing the database or data layer.
