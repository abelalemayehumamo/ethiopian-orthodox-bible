# Bible Data — Source, License, and Import

## Current status: NO BIBLE TEXT IS BUNDLED

This repository ships **zero verses**. `src/data/canon.json` contains only the
book list (id, testament, Amharic name, English reference name) and, for the
66 books shared with virtually every Christian canon, chapter counts that are
stable and undisputed. It does **not** contain scripture text.

## Why

1. The Ethiopian Orthodox Tewahedo Church (EOTC) canon has **81 books**
   (46 Old Testament + 35 New Testament, per the Church's own public
   teaching), not the 66-book Protestant canon most free datasets use.
2. The commonly available Amharic Bible translations are **not confirmed
   public domain**. I could not locate a verified open license for a
   complete, EOTC-canon Amharic dataset. Bible societies and/or the Church
   itself typically hold rights to modern Amharic translations.
3. Even if I found *an* Amharic text online, using it without confirming its
   license would risk shipping copyright-infringing content in your app —
   this could get the app pulled from Google Play and expose you to legal
   risk. I won't do that regardless of how the request is phrased.

## What you need to do

Obtain **written permission or a licensed dataset** from one of:
- The Bible Society of Ethiopia
- The Ethiopian Orthodox Tewahedo Church's official publishing body
- A commercial Bible-data licensor that explicitly covers the Amharic EOTC
  canon (confirm the license text explicitly permits redistribution inside
  a mobile app, not just personal/web use)

## Required input format

Once you have a legal source, convert it to this JSON shape (or use
`scripts/import-bible` for CSV/pipe-delimited TXT sources):

```json
[
  {
    "book_id": "gen",
    "testament": "old",
    "chapters": [
      { "chapter": 1, "verses": [ { "verse": 1, "text": "..." } ] }
    ]
  }
]
```

`book_id` must match an id in `src/data/canon.json`. If your source uses the
fuller 81-book EOTC canon, first fill in the placeholder entries in
`canon.json` (currently 46 OT + 32 NT = 78 slots, with several
Ethiopian-canon-unique books deliberately left as documented gaps — see the
`_placeholder_note` in that file) using your source's own table of contents,
so book identity and ordering come from an authoritative document rather
than a guess.

## Pipeline

```
raw file (csv/txt/other) → scripts/import-bible → data/raw/bible.json
                                                        │
                                                        ▼
                                          scripts/validate-bible (must PASS)
                                                        │
                                                        ▼
                                          scripts/build-database → bible.db
                                                        │
                                                        ▼
                                android/app/src/main/assets/bible.db (bundled)
```

Never skip validation. `build-database` does not re-validate for you.
