# Build

## Debug APK

```
npm run android            # builds + installs on running emulator/device
```
or explicitly:
```
npm run build:apk:debug
```
Output: `android/app/build/outputs/apk/debug/app-debug.apk`

## Release APK / AAB

Requires a signing keystore first — see `SIGNING.md`. Do not run these until
`android/app/build.gradle` points at a real keystore, or the build will fail
(intentionally — an unsigned "release" build is not something Play Store or
most devices will install).

```
npm run build:apk     # android/app/build/outputs/apk/release/app-release.apk
npm run build:aab     # android/app/build/outputs/bundle/release/app-release.aab
```

Prefer the **AAB** for Play Store upload (Play requires AAB for new apps);
keep the APK for direct/local install testing (sideloading, QA on a device
without Play access).

## If a build fails

- `Execution failed for task ':app:mergeDebugResources'` → usually a missing
  vector-icon font or duplicate resource name; check
  `android/app/src/main/res/`.
- `SDK location not found` → `ANDROID_HOME` not set, see `SETUP.md`.
- `Keystore file ... not found` → see `SIGNING.md`, you haven't created one
  yet or the path in `build.gradle`/`keystore.properties` is wrong.

This project has not had a build actually executed in the environment that
generated it (no Android SDK available there) — treat the gradle
configuration as a correct-by-inspection starting point, not something
already proven to build clean. Report the exact first error you hit if one
comes up; gradle configs are finicky and worth fixing precisely rather than
guessing around.
