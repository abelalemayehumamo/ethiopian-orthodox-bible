# Database

Two physical SQLite files, deliberately kept separate:

| File       | Contents                                              | Lifecycle |
|------------|--------------------------------------------------------|-----------|
| `bible.db` | `books`, `chapters`, `verses`, `verses_fts`            | Bundled read-only asset, replaced whenever you ship an updated/corrected Bible text build |
| `user.db`  | `bookmarks`, `highlights`, `notes`, `reading_history`, `settings` | Created on first launch, lives in app-private storage, never touched by app updates |

This split means shipping a corrected translation or filling in a missing
book never risks wiping a user's bookmarks.

## Tables

- **books** — one row per canonical book. `chapter_count`/`verified` reflect
  reality (see `src/data/canon.json`), not aspiration.
- **chapters** — `verse_count` is derived at import time from the actual
  imported verses, never hard-coded, so it can't drift from real data.
- **verses** — the text itself. Primary key `(book_id, chapter_number,
  verse_number)`.
- **verses_fts** — FTS5 virtual table mirroring `verses.text`, kept in sync
  via `AFTER INSERT/UPDATE/DELETE` triggers. Search strategy: FTS5's
  `unicode61` tokenizer operates at the Unicode codepoint level, which is
  sufficient for Ge'ez/Amharic word and substring search without needing a
  language-specific stemmer (Amharic morphology is complex enough that a
  proper stemmer is out of scope for v1 — documented as a known limitation).
- **bookmarks / highlights / notes / reading_history / settings** — user
  data, described in `schema.sql`.

## Migrations

`schema_meta.schema_version` is checked at startup. Any future schema change
ships a numbered migration in `src/database/migrations/00N_description.sql`
and a matching entry in `src/database/migrationRunner.ts` (not yet needed at
v1, since the app has not shipped yet — documented here so the pattern is
established before it's needed).
