# Licenses

- **App source code**: yours to license as you choose (add a LICENSE file;
  MIT is a reasonable default for the app shell, independent of the Bible
  text license below).
- **Bible text**: NOT INCLUDED. Whatever source you obtain will carry its
  own license/permission terms — record them here once known, including:
  - Source name and publisher
  - Whether it's public domain, licensed, or church-authorized
  - Any required in-app attribution text (add it to `AboutScreen.tsx`)
  - Any restrictions (e.g. non-commercial only, no redistribution outside
    this specific app, etc.)
- **Fonts/icons**: this scaffold uses only system fonts and text glyphs (no
  bundled Amharic font, no icon library wired up yet — see Section 40 of the
  brief). If you add `react-native-vector-icons` glyphs or a custom Ethiopic
  font (e.g. Noto Sans Ethiopic, which is OFL-licensed and safe to bundle),
  record that here too.
