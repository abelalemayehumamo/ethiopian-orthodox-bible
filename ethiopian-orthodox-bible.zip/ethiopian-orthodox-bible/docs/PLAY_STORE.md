# Google Play Release Checklist

Google Play's exact requirements change over time — verify current details
at https://play.google.com/console before submitting; this list is a
structural checklist, not a guarantee of what Play currently requires.

- [ ] Google Play Console developer account (one-time registration fee)
- [ ] Create app → set default language (Amharic + English), app name
- [ ] Package ID: reverse-domain, e.g. `com.yourorg.ethiopianorthodoxbible`
      (set in `android/app/build.gradle` → `applicationId`, and matches
      `app.json`/`AndroidManifest.xml` package)
- [ ] Store listing: short description, full description, screenshots
      (phone + tablet if supported), feature graphic, app icon (512×512)
- [ ] Privacy policy URL — required even for an offline app if you collect
      any data at all; if truly zero data leaves the device, say so
      explicitly in the policy
- [ ] Data safety form — declare what user data is collected (likely "none"
      for this app if bookmarks/history stay local-only, but confirm against
      your actual final feature set, e.g. if you add crash reporting/analytics)
- [ ] Content rating questionnaire
- [ ] Target audience & content settings
- [ ] App access — confirm no login is required, or provide test credentials
      if one exists
- [ ] Upload signed AAB (see BUILD.md / SIGNING.md)
- [ ] Set version name/code in `android/app/build.gradle`
      (`versionName`, `versionCode` — increment `versionCode` every release)
- [ ] Choose release track: Internal testing → Closed testing → Production
- [ ] Review and submit

## Permissions

This app requests **no dangerous permissions** by default (no camera,
location, contacts, microphone) — confirm `AndroidManifest.xml` still
reflects that before submission if you add any native module later.
