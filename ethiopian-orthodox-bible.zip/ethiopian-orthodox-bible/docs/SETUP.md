# Setup — From a Fresh Computer

## Windows

1. **Node.js LTS** (≥18): https://nodejs.org → install → verify: `node -v`
2. **Git**: https://git-scm.com/download/win → verify: `git --version`
3. **JDK 17**: install Microsoft Build of OpenJDK 17, set `JAVA_HOME` to its
   install path in System Environment Variables.
4. **Android Studio**: https://developer.android.com/studio
   - During setup, install: Android SDK Platform 34, Android SDK Build-Tools,
     Android Emulator, Android SDK Platform-Tools.
   - Set environment variables (System Properties → Environment Variables):
     - `ANDROID_HOME` = `C:\Users\<you>\AppData\Local\Android\Sdk`
     - Add to `Path`: `%ANDROID_HOME%\platform-tools`, `%ANDROID_HOME%\emulator`
5. **VS Code**: https://code.visualstudio.com — install extensions:
   ESLint, Prettier, React Native Tools.
6. In Android Studio → Device Manager → create a virtual device (e.g. Pixel
   6, API 34).
7. Clone/unzip this project, then:
   ```
   cd ethiopian-orthodox-bible
   npm install
   npm run env-check
   ```
8. Start the emulator from Android Studio's Device Manager, then:
   ```
   npm run android
   ```

## macOS / Linux

Same steps, differences:
- JDK: `brew install openjdk@17` (macOS) or your distro's package manager.
- `ANDROID_HOME` goes in `~/.zshrc`/`~/.bashrc`:
  ```
  export ANDROID_HOME=$HOME/Library/Android/sdk   # macOS
  export ANDROID_HOME=$HOME/Android/Sdk           # Linux
  export PATH=$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/emulator
  ```

## VS Code project config

Already included: `.editorconfig`, `.eslintrc.js`, `.prettierrc`,
`tsconfig.json`. Format on save: enable "Editor: Format On Save" and set
Prettier as the default formatter for `.ts`/`.tsx`.

## Physical device testing

1. On the phone: Settings → About Phone → tap "Build number" 7 times to
   enable Developer Options.
2. Settings → Developer Options → enable **USB debugging**.
3. Connect via USB, accept the "Allow USB debugging?" prompt on the phone.
4. Verify: `adb devices` shows your device.
5. `npm run android` installs and launches directly on the phone instead of
   an emulator (if only one device/emulator is connected).

## Commands reference

| Command | Purpose |
|---|---|
| `npm install` | install dependencies |
| `npm run android` | build+run debug app on emulator/device |
| `npm start` | start Metro bundler only |
| `npm test` | run Jest unit tests |
| `npm run lint` / `npm run format` | ESLint / Prettier |
| `npm run typecheck` | TypeScript check, no emit |
| `npm run env-check` | verify local toolchain |
| `npm run import-bible -- --input <file> --format csv\|txt --out data/raw/bible.json` | convert raw source to canonical JSON |
| `npm run validate-bible -- --input data/raw/bible.json` | validate before building DB |
| `npm run build-bible-db -- --input data/raw/bible.json` | build `bible.db` asset |
| `npm run build:apk:debug` | debug APK |
| `npm run build:apk` | release APK (needs signing, see SIGNING.md) |
| `npm run build:aab` | release AAB for Play Store |
