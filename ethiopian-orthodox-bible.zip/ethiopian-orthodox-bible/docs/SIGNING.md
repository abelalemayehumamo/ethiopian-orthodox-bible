# Release Signing

## 1. Create a keystore (once, ever — back this up permanently)

```
keytool -genkeypair -v -storetype PKCS12 -keystore eob-release.keystore ^
  -alias eob-release -keyalg RSA -keysize 2048 -validity 10000
```
(macOS/Linux: same command, replace `^` line breaks with `\`.)

You'll be prompted for a keystore password and key password — use strong,
unique passwords and store them in a password manager, not in this repo.

## 2. NEVER commit the keystore or passwords

`.gitignore` already excludes `*.keystore`, `*.jks`, and
`keystore.properties`. Keep a secure backup (encrypted drive, password
manager attachment, etc.) — **if you lose this keystore, you cannot publish
updates to the same Play Store listing ever again.** Google cannot recover
it for you.

## 3. Configure Gradle

Create `android/keystore.properties` (NOT committed):
```
storeFile=/absolute/path/to/eob-release.keystore
storePassword=YOUR_STORE_PASSWORD
keyAlias=eob-release
keyPassword=YOUR_KEY_PASSWORD
```

`android/app/build.gradle` (included in this scaffold) already reads this
file and applies it to the `release` signing config — see the
`signingConfigs` block.

## 4. Build

```
npm run build:aab
```

If `keystore.properties` is missing, the release build intentionally fails
with a clear error rather than producing an unsigned artifact.
