# Testing

## What has actually been run in this environment

- `scripts/validate-bible` was executed against two synthetic (non-Bible)
  fixtures — one internally consistent, one deliberately broken — and
  correctly reported PASS / FAIL with accurate error detail (duplicate
  verse, empty verse, duplicate chapter, testament mismatch). This confirms
  the validation *logic* works.
- Nothing else in this project has been executed, because this sandbox has
  no Android SDK, no emulator, and no network access to install
  `node_modules`. Everything below is unverified until you run it yourself.

## What you must verify yourself, and how

1. `npm install` completes without errors.
2. `npm run typecheck` — no TypeScript errors.
3. `npm run lint` — no ESLint errors.
4. `npm test` — unit tests pass (add tests under `tests/unit` alongside
   `BibleRepository`, `BookmarkService`, `HistoryService` as you build out
   real data; a couple of starter specs are included).
5. `npm run android` on an emulator — app boots, shows the empty-state
   messages (since no Bible text is bundled yet), navigation/back-button/
   theme toggle all work.
6. Airplane-mode test (Section 43 of the brief): once real data is imported,
   enable airplane mode and confirm Browse/Search/Bookmark/History/Settings
   all still work — none of this app's code makes network calls at runtime.
7. Release build: `npm run build:apk` then `build:aab` (see BUILD.md).

Report results honestly in your own copy of this file as you go — don't mark
a box done until you've actually seen it pass.
