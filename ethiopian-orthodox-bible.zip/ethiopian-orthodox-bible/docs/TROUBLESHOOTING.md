# Troubleshooting

## "cd : Cannot find path '...\android\ethiopian-orthodox-bible' because it does not exist"

You were already inside the `android/` folder and tried to `cd` into the
project folder again. Run all `npm` commands from the **project root**:

```
cd C:\Users\<you>\Documents\ethiopian-orthodox-bible
npm install
```
Not from inside `...\ethiopian-orthodox-bible\android`.

## `npm install` fails after a wall of `npm warn deprecated` lines

The warnings themselves (`inflight`, `rimraf@3`, `glob@7.2.3`,
`@humanwhocodes/*`, `eslint@8.57.1`) are not the failure — they're just
noise from an old ESLint 8 dependency chain. This project has been updated
to ESLint 9 (`eslint.config.js` flat config) specifically to stop pulling
those packages in. The actual failure is always an `npm error` line further
down, or in the log file npm points you to. Get it with:

```
Get-Content "$env:LOCALAPPDATA\npm-cache\_logs\<the-file-npm-named>.log" -Tail 40
```

Common causes once you see the real error:

- **ERESOLVE / peer dependency conflict** → run
  `npm install --legacy-peer-deps` once to confirm it's a peer-dep issue,
  then report back the specific package pair npm names so the version
  range in `package.json` can be fixed properly instead of permanently
  overriding peer resolution.
- **`ETIMEDOUT` / `ENOTFOUND` / registry errors** → network/proxy/firewall
  issue on your machine, not a project bug. Check
  `npm config get registry` (should be `https://registry.npmjs.org/`) and
  your network/VPN/antivirus.
- **`EACCES` (Windows permissions)** → run the terminal as your normal user
  in your own `Documents` folder, not an admin-protected path.

## Android Studio: "Gradle project sync failed"

This is almost always downstream of `npm install` not having completed —
`android/settings.gradle` requires `node_modules/@react-native-community/
cli-platform-android` to exist. Fix `npm install` first, then in Android
Studio: File → Sync Project with Gradle Files.

If sync still fails after a clean `npm install`, click "Show Log in
Explorer" / check the Build panel for the **first** error (not the last) —
Gradle often cascades one root cause into many downstream failures.

## Reporting a build error to get an accurate fix

Paste the exact error text, not a screenshot of warnings. The most useful
excerpt is the line starting with `npm error code ...` (for npm) or the
first `FAILURE: Build failed with an exception` block with the task name
right above it (for Gradle).

## Missing Gradle wrapper (`gradlew` fails with "not found")

This scaffold ships `android/gradle/wrapper/gradle-wrapper.properties`
(tells Gradle which version to use) but not the wrapper binary/jar itself —
that's a small binary file that shouldn't be hand-authored blind.

- **In Android Studio**: when you open `android/` and it notices the
  wrapper is incomplete, it will typically prompt you to let it generate
  the wrapper using its bundled Gradle. Accept that prompt.
- **On the command line / CI**: install Gradle 8.10.2 once (or use a CI
  action like `gradle/actions/setup-gradle`, as `.github/workflows/build-apk.yml`
  does), then from `android/` run `gradle wrapper --gradle-version 8.10.2`
  to generate `gradlew`, `gradlew.bat`, and the jar. After that, `./gradlew`
  works normally for every future build.

## Free CI APK builds (GitHub Actions)

See the root `.github/workflows/build-apk.yml` — pushing changes to
`ethiopian-orthodox-bible.zip` on `main`, or clicking "Run workflow" in the
Actions tab, builds a debug APK and attaches it to the run as a downloadable
artifact. No payment, no local Android SDK required. It currently builds
against an intentionally empty (schema-only, 0 verses) Bible database so the
app boots — see docs/BIBLE_DATA.md for why.
