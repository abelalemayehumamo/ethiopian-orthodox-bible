// ESLint 9 flat config — replaces the old .eslintrc.js. Using the flat
// config entry point avoids pulling in @react-native/eslint-config's legacy
// eslintrc-mode dependency chain (old rimraf/glob/inflight/humanwhocodes
// versions), which is what produced the "deprecated" npm warnings you saw.
const reactNativeConfig = require('@react-native/eslint-config/flat');

module.exports = [
  ...reactNativeConfig,
  {
    rules: {
      '@typescript-eslint/no-explicit-any': 'warn',
    },
  },
];
