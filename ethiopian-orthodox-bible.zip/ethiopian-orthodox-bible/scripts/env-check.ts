/**
 * Checks whether the local development machine has everything needed to
 * build this project. Run with: npm run env-check
 */
import { execSync } from 'child_process';

function check(label: string, cmd: string, minVersionHint?: string): void {
  try {
    const out = execSync(cmd, { stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim().split('\n')[0];
    console.log(`${label}: PASS  (${out}${minVersionHint ? ` — need ${minVersionHint}` : ''})`);
  } catch {
    console.log(`${label}: FAIL — not found on PATH. See docs/SETUP.md for install instructions.`);
  }
}

console.log('Environment check');
console.log('==================');
check('Node', 'node -v', '>=18');
check('npm', 'npm -v');
check('Java (JDK)', 'java -version', 'JDK 17 for RN 0.75');
check('ADB', 'adb --version');
check('Git', 'git --version');
try {
  execSync('npx react-native --version', { stdio: ['ignore', 'pipe', 'ignore'] });
  console.log('React Native CLI: PASS');
} catch {
  console.log('React Native CLI: FAIL — run `npm install` first.');
}
console.log('');
console.log('Note: ANDROID_HOME / Android SDK cannot be verified from Node alone reliably on all shells.');
console.log('Confirm manually: echo $ANDROID_HOME (macOS/Linux) or echo %ANDROID_HOME% (Windows).');
