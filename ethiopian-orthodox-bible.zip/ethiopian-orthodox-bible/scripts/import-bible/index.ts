/**
 * Convenience wrapper: converts common raw formats (plain .txt with a
 * pipe-delimited line format, or .csv with columns book_id,testament,
 * chapter,verse,text) into the canonical JSON shape expected by
 * validate-bible and build-database. This does NOT supply any Bible text
 * itself — point it at a file you have the legal right to use.
 *
 * Usage:
 *   npm run import-bible -- --input data/raw/bible.csv --format csv --out data/raw/bible.json
 *   npm run import-bible -- --input data/raw/bible.txt --format txt --out data/raw/bible.json
 */
import * as fs from 'fs';
import * as path from 'path';

function getArg(name: string): string | undefined {
  const idx = process.argv.indexOf(`--${name}`);
  return idx >= 0 ? process.argv[idx + 1] : undefined;
}

interface Book { book_id: string; testament: 'old' | 'new'; chapters: { chapter: number; verses: { verse: number; text: string }[] }[] }

function fromCsv(content: string): Book[] {
  const lines = content.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const header = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const idx = {
    book_id: header.indexOf('book_id'),
    testament: header.indexOf('testament'),
    chapter: header.indexOf('chapter'),
    verse: header.indexOf('verse'),
    text: header.indexOf('text'),
  };
  if (Object.values(idx).some((v) => v === -1)) {
    throw new Error('CSV must have header columns: book_id,testament,chapter,verse,text');
  }

  const booksMap = new Map<string, Book>();
  for (let i = 1; i < lines.length; i++) {
    // Naive comma split — swap for a proper CSV parser (e.g. papaparse) if
    // your source text can contain literal commas.
    const cols = lines[i].split(',');
    const bookId = cols[idx.book_id].trim();
    const testament = cols[idx.testament].trim() as 'old' | 'new';
    const chapterNum = parseInt(cols[idx.chapter], 10);
    const verseNum = parseInt(cols[idx.verse], 10);
    const text = cols.slice(idx.text).join(',').trim();

    if (!booksMap.has(bookId)) booksMap.set(bookId, { book_id: bookId, testament, chapters: [] });
    const book = booksMap.get(bookId)!;
    let chapter = book.chapters.find((c) => c.chapter === chapterNum);
    if (!chapter) {
      chapter = { chapter: chapterNum, verses: [] };
      book.chapters.push(chapter);
    }
    chapter.verses.push({ verse: verseNum, text });
  }
  return Array.from(booksMap.values());
}

function fromTxt(content: string): Book[] {
  // Expected line format: "gen|old|1|1|In the beginning..."
  const lines = content.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const booksMap = new Map<string, Book>();
  for (const line of lines) {
    const parts = line.split('|');
    if (parts.length < 5) continue;
    const [bookId, testament, chapterStr, verseStr, ...textParts] = parts;
    const chapterNum = parseInt(chapterStr, 10);
    const verseNum = parseInt(verseStr, 10);
    const text = textParts.join('|').trim();

    if (!booksMap.has(bookId)) booksMap.set(bookId, { book_id: bookId, testament: testament as 'old' | 'new', chapters: [] });
    const book = booksMap.get(bookId)!;
    let chapter = book.chapters.find((c) => c.chapter === chapterNum);
    if (!chapter) {
      chapter = { chapter: chapterNum, verses: [] };
      book.chapters.push(chapter);
    }
    chapter.verses.push({ verse: verseNum, text });
  }
  return Array.from(booksMap.values());
}

function main() {
  const input = getArg('input');
  const format = getArg('format');
  const out = getArg('out') ?? 'data/raw/bible.json';

  if (!input || !format) {
    console.error('Usage: npm run import-bible -- --input <file> --format csv|txt --out <output.json>');
    process.exit(1);
  }
  const content = fs.readFileSync(path.resolve(input), 'utf-8');
  const books = format === 'csv' ? fromCsv(content) : format === 'txt' ? fromTxt(content) : null;
  if (!books) {
    console.error(`Unsupported format: ${format}. Use csv or txt, or write your own converter for json/xml sources.`);
    process.exit(1);
  }

  fs.mkdirSync(path.dirname(path.resolve(out)), { recursive: true });
  fs.writeFileSync(path.resolve(out), JSON.stringify(books, null, 2), 'utf-8');
  console.log(`Wrote ${books.length} books to ${out}`);
  console.log('Next: npm run validate-bible -- --input ' + out);
}

main();
