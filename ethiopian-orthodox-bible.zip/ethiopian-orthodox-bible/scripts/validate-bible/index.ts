/**
 * Validates a source Bible dataset BEFORE it is imported into bible.db.
 *
 * Usage:
 *   npm run validate-bible -- --input data/raw/bible.json
 *
 * Expected input schema (one file, array of book objects):
 * [
 *   {
 *     "book_id": "gen",
 *     "testament": "old",
 *     "chapters": [
 *       { "chapter": 1, "verses": [ { "verse": 1, "text": "..." }, ... ] }
 *     ]
 *   },
 *   ...
 * ]
 *
 * This script does NOT fabricate or download any Bible text. It only
 * checks whatever file you point it at.
 */
import * as fs from 'fs';
import * as path from 'path';
import canon from '../../src/data/canon.json';

interface SourceVerse { verse: number; text: string }
interface SourceChapter { chapter: number; verses: SourceVerse[] }
interface SourceBook { book_id: string; testament: 'old' | 'new'; chapters: SourceChapter[] }

interface ValidationIssue { level: 'error' | 'warning'; message: string }

function getArg(name: string): string | undefined {
  const idx = process.argv.indexOf(`--${name}`);
  return idx >= 0 ? process.argv[idx + 1] : undefined;
}

function isValidUnicodeText(text: string): boolean {
  if (typeof text !== 'string') return false;
  // Reject lone surrogate / replacement-character corruption, a common sign
  // of a mis-decoded Ethiopic source file.
  return !text.includes('\uFFFD') && text.trim().length > 0;
}

function main() {
  const inputPath = getArg('input');
  if (!inputPath) {
    console.error('Usage: npm run validate-bible -- --input <path-to-bible.json>');
    process.exit(1);
  }
  const resolved = path.resolve(inputPath);
  if (!fs.existsSync(resolved)) {
    console.error(`Input file not found: ${resolved}`);
    console.error('No Bible dataset has been supplied yet — see docs/BIBLE_DATA.md for the required format and legal sourcing requirements.');
    process.exit(1);
  }

  const raw = fs.readFileSync(resolved, 'utf-8');
  let data: SourceBook[];
  try {
    data = JSON.parse(raw);
  } catch (e) {
    console.error('Input file is not valid JSON:', (e as Error).message);
    process.exit(1);
  }

  const issues: ValidationIssue[] = [];
  const canonBookIds = new Set(canon.books.map((b: any) => b.id));
  const seenBookIds = new Set<string>();

  let totalChapters = 0;
  let totalVerses = 0;
  let oldCount = 0;
  let newCount = 0;
  let duplicateVerses = 0;
  let emptyVerses = 0;
  let invalidUnicode = 0;
  let missingChapterNumbers = 0;
  let outOfOrderChapters = 0;

  for (const book of data) {
    if (!book.book_id) {
      issues.push({ level: 'error', message: 'A book entry is missing book_id.' });
      continue;
    }
    if (seenBookIds.has(book.book_id)) {
      issues.push({ level: 'error', message: `Duplicate book_id: ${book.book_id}` });
    }
    seenBookIds.add(book.book_id);

    if (!canonBookIds.has(book.book_id)) {
      issues.push({ level: 'warning', message: `book_id "${book.book_id}" is not in src/data/canon.json — add it there first or it will be rejected at import.` });
    }

    const canonEntry: any = canon.books.find((b: any) => b.id === book.book_id);
    if (canonEntry && canonEntry.testament !== book.testament) {
      issues.push({ level: 'error', message: `Testament mismatch for ${book.book_id}: canon says "${canonEntry.testament}", file says "${book.testament}".` });
    }
    if (book.testament === 'old') oldCount++;
    if (book.testament === 'new') newCount++;

    let lastChapterNum = 0;
    const seenChapterNums = new Set<number>();
    for (const chapter of book.chapters ?? []) {
      if (chapter.chapter == null) {
        missingChapterNumbers++;
        issues.push({ level: 'error', message: `${book.book_id}: a chapter entry has no chapter number.` });
        continue;
      }
      if (seenChapterNums.has(chapter.chapter)) {
        issues.push({ level: 'error', message: `${book.book_id}: duplicate chapter number ${chapter.chapter}.` });
      }
      seenChapterNums.add(chapter.chapter);
      if (chapter.chapter < lastChapterNum) {
        outOfOrderChapters++;
        issues.push({ level: 'error', message: `${book.book_id}: chapter ${chapter.chapter} appears out of order.` });
      }
      lastChapterNum = chapter.chapter;
      totalChapters++;

      const seenVerseNums = new Set<number>();
      let lastVerseNum = 0;
      for (const verse of chapter.verses ?? []) {
        totalVerses++;
        if (seenVerseNums.has(verse.verse)) {
          duplicateVerses++;
          issues.push({ level: 'error', message: `${book.book_id} ${chapter.chapter}:${verse.verse} is a duplicate verse number.` });
        }
        seenVerseNums.add(verse.verse);
        if (verse.verse !== lastVerseNum + 1 && lastVerseNum !== 0) {
          issues.push({ level: 'warning', message: `${book.book_id} ${chapter.chapter}: verse numbering jumps from ${lastVerseNum} to ${verse.verse}.` });
        }
        lastVerseNum = verse.verse;

        if (!verse.text || verse.text.trim().length === 0) {
          emptyVerses++;
          issues.push({ level: 'error', message: `${book.book_id} ${chapter.chapter}:${verse.verse} has empty text.` });
        } else if (!isValidUnicodeText(verse.text)) {
          invalidUnicode++;
          issues.push({ level: 'error', message: `${book.book_id} ${chapter.chapter}:${verse.verse} contains invalid/corrupted Unicode.` });
        }
      }
    }
  }

  const missingBooks = canon.books.filter((b: any) => !seenBookIds.has(b.id));
  const errorCount = issues.filter((i) => i.level === 'error').length;
  const warningCount = issues.filter((i) => i.level === 'warning').length;

  console.log('Bible Validation Report');
  console.log('=======================');
  console.log(`Books present:      ${seenBookIds.size} / ${canon.books.length} in canon.json`);
  console.log(`  Old Testament:    ${oldCount}`);
  console.log(`  New Testament:    ${newCount}`);
  console.log(`Chapters:           ${totalChapters}`);
  console.log(`Verses:             ${totalVerses}`);
  console.log(`Missing books:      ${missingBooks.length}${missingBooks.length ? ' (' + missingBooks.map((b: any) => b.id).join(', ') + ')' : ''}`);
  console.log(`Missing chapter #s: ${missingChapterNumbers}`);
  console.log(`Out-of-order chapters: ${outOfOrderChapters}`);
  console.log(`Duplicate verses:   ${duplicateVerses}`);
  console.log(`Empty verses:       ${emptyVerses}`);
  console.log(`Invalid Unicode:    ${invalidUnicode}`);
  console.log(`Errors:             ${errorCount}`);
  console.log(`Warnings:           ${warningCount}`);
  console.log('');

  if (issues.length > 0) {
    console.log('Details:');
    for (const issue of issues.slice(0, 200)) {
      console.log(`  [${issue.level.toUpperCase()}] ${issue.message}`);
    }
    if (issues.length > 200) console.log(`  ...and ${issues.length - 200} more.`);
  }

  const status = errorCount === 0 ? 'PASS' : 'FAIL';
  console.log('');
  console.log(`STATUS: ${status}`);
  if (status === 'FAIL') {
    process.exit(1);
  }
}

main();
