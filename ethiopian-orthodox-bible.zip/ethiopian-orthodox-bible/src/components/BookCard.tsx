import React from 'react';
import { TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import { useAppTheme } from '@/context/ThemeContext';
import { spacing, radius } from '@/theme/theme';
import { BookMeta } from '@/types/bible';

export default function BookCard({ book, onPress }: { book: BookMeta; onPress: () => void }) {
  const { theme } = useAppTheme();
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.card, { backgroundColor: theme.surfaceGlass, borderColor: theme.border }]}
    >
      <Text style={[styles.name, { color: theme.textPrimary }]}>{book.nameAm}</Text>
      <View style={styles.metaRow}>
        <Text style={[styles.meta, { color: theme.textSecondary }]}>
          {book.chapterCount != null ? `${book.chapterCount} ምዕራፎች` : 'ምዕራፎች ይታያል'}
        </Text>
        {!book.verified && <Text style={[styles.badge, { color: theme.accent }]}>⚠ ያልተረጋገጠ</Text>}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    padding: spacing.md,
    marginHorizontal: spacing.md,
    marginVertical: spacing.xs,
  },
  name: { fontSize: 17, fontWeight: '600' },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.xs },
  meta: { fontSize: 13 },
  badge: { fontSize: 12, fontWeight: '600' },
});
