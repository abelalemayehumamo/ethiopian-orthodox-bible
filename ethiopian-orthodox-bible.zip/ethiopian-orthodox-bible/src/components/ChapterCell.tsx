import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useAppTheme } from '@/context/ThemeContext';
import { radius } from '@/theme/theme';

export default function ChapterCell({ number, onPress }: { number: number; onPress: () => void }) {
  const { theme } = useAppTheme();
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.cell, { backgroundColor: theme.surfaceGlass, borderColor: theme.border }]}
    >
      <Text style={{ color: theme.textPrimary, fontWeight: '600' }}>{number}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  cell: {
    width: 56,
    height: 56,
    margin: 6,
    borderRadius: radius.sm,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
