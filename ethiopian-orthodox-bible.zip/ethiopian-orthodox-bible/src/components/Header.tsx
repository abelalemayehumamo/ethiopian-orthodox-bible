import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useNavigation, DrawerActions } from '@react-navigation/native';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { useAppTheme } from '@/context/ThemeContext';
import { spacing } from '@/theme/theme';

/**
 * Shared header used on every screen. Shows a hamburger icon on root-level
 * screens and a back arrow elsewhere (React Navigation tells us via
 * props.back). Search/Bookmark shortcut icons are optional per-screen via
 * options passed through navigation (kept simple here: always shown on the
 * Reader route, which the router matches by props.route.name).
 */
export default function Header(props: NativeStackHeaderProps) {
  const { theme } = useAppTheme();
  const navigation = useNavigation();
  const canGoBack = !!props.back;

  return (
    <View style={[styles.container, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
      <TouchableOpacity
        accessibilityLabel={canGoBack ? 'ወደኋላ' : 'ማውጫ ክፈት'}
        onPress={() => (canGoBack ? props.navigation.goBack() : navigation.dispatch(DrawerActions.openDrawer()))}
        style={styles.iconButton}
      >
        <Text style={[styles.iconText, { color: theme.textPrimary }]}>{canGoBack ? '←' : '☰'}</Text>
      </TouchableOpacity>

      <Text style={[styles.title, { color: theme.textPrimary }]} numberOfLines={1}>
        {props.options.title ?? props.route.name}
      </Text>

      {props.route.name === 'Reader' ? (
        <TouchableOpacity
          accessibilityLabel="ፍለጋ"
          onPress={() => props.navigation.navigate('Search' as never)}
          style={styles.iconButton}
        >
          <Text style={[styles.iconText, { color: theme.textPrimary }]}>🔍</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.iconButton} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    height: Platform.select({ android: 56, default: 56 }),
    paddingHorizontal: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  iconButton: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  iconText: { fontSize: 20 },
  title: { flex: 1, fontSize: 18, fontWeight: '600', textAlign: 'center' },
});
