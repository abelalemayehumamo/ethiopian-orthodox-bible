import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { DrawerContentComponentProps } from '@react-navigation/drawer';
import { CommonActions } from '@react-navigation/native';
import { useAppTheme } from '@/context/ThemeContext';
import { spacing, radius } from '@/theme/theme';

const ITEMS: { label: string; route: string; params?: object }[] = [
  { label: 'መነሻ', route: 'Home' },
  { label: 'ብሉይ ኪዳን', route: 'BookList', params: { testament: 'old' } },
  { label: 'ሐዲስ ኪዳን', route: 'BookList', params: { testament: 'new' } },
  { label: 'ፍለጋ', route: 'Search' },
  { label: 'የተቀመጡ', route: 'Bookmarks' },
  { label: 'የቅርብ ጊዜ ንባብ', route: 'History' },
  { label: 'ቅንብሮች', route: 'Settings' },
  { label: 'ስለ መተግበሪያው', route: 'About' },
];

export default function DrawerContent(props: DrawerContentComponentProps) {
  const { theme } = useAppTheme();

  const go = (route: string, params?: object) => {
    props.navigation.dispatch(
      CommonActions.navigate({ name: 'Main', params: { screen: route, params } }),
    );
    props.navigation.closeDrawer();
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.surface }]}>
      <View style={[styles.brand, { borderBottomColor: theme.border }]}>
        <Text style={[styles.brandTitle, { color: theme.accent }]}>መጽሐፍ ቅዱስ</Text>
        <Text style={[styles.brandSubtitle, { color: theme.textSecondary }]}>የኢትዮጵያ ኦርቶዶክስ ተዋሕዶ</Text>
      </View>
      <ScrollView>
        {ITEMS.map((item) => (
          <TouchableOpacity key={item.label} style={styles.item} onPress={() => go(item.route, item.params)}>
            <Text style={[styles.itemText, { color: theme.textPrimary }]}>{item.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  brand: { padding: spacing.lg, borderBottomWidth: StyleSheet.hairlineWidth },
  brandTitle: { fontSize: 22, fontWeight: '700' },
  brandSubtitle: { fontSize: 13, marginTop: 2 },
  item: { paddingVertical: spacing.md, paddingHorizontal: spacing.lg, borderRadius: radius.sm },
  itemText: { fontSize: 16 },
});
