import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useAppTheme } from '@/context/ThemeContext';
import { spacing } from '@/theme/theme';
import { Verse, ReaderSettings } from '@/types/bible';

interface Props {
  verse: Verse;
  settings: ReaderSettings;
  bookmarked: boolean;
  onLongPress: (verse: Verse) => void;
}

export default function VerseItem({ verse, settings, bookmarked, onLongPress }: Props) {
  const { theme } = useAppTheme();
  return (
    <TouchableOpacity activeOpacity={0.7} onLongPress={() => onLongPress(verse)} style={styles.row}>
      <Text style={[styles.number, { color: theme.accent, fontSize: settings.fontSizeSp * 0.6 }]}>
        {verse.verseNumber}
      </Text>
      <Text
        style={[
          styles.text,
          {
            color: theme.textPrimary,
            fontSize: settings.fontSizeSp,
            lineHeight: settings.fontSizeSp * settings.lineHeightMultiplier,
          },
        ]}
      >
        {verse.text}
        {bookmarked ? ' 🔖' : ''}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', paddingHorizontal: spacing.md, paddingVertical: spacing.xs, alignItems: 'flex-start' },
  number: { fontWeight: '700', marginRight: spacing.sm, marginTop: 4, minWidth: 20 },
  text: { flex: 1 },
});
