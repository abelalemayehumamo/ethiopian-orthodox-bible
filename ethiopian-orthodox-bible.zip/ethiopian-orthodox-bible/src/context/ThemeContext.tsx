import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import { AppTheme, darkTheme, lightTheme } from '@/theme/theme';
import { settingsService } from '@/services/SettingsService';
import { ThemeMode } from '@/types/bible';

interface ThemeContextValue {
  theme: AppTheme;
  mode: ThemeMode;
  setMode: (m: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const systemScheme = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>('system');

  useEffect(() => {
    settingsService.get().then((s) => setModeState(s.themeMode));
  }, []);

  const setMode = (m: ThemeMode) => {
    setModeState(m);
    settingsService.set('themeMode', m);
  };

  const resolvedDark = mode === 'system' ? systemScheme === 'dark' : mode === 'dark';
  const theme = useMemo(() => (resolvedDark ? darkTheme : lightTheme), [resolvedDark]);

  return <ThemeContext.Provider value={{ theme, mode, setMode }}>{children}</ThemeContext.Provider>;
};

export function useAppTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useAppTheme must be used within ThemeProvider');
  return ctx;
}
