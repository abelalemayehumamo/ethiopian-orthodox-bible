import SQLite, { SQLiteDatabase } from 'react-native-sqlite-storage';

SQLite.enablePromise(true);

/**
 * Two physical databases are opened, on purpose:
 *  - bible.db  : read-mostly Bible text, bundled with the app, replaceable
 *                on app updates without touching user data.
 *  - user.db   : bookmarks/highlights/notes/history/settings, created on
 *                first launch, never overwritten by an app update.
 * See docs/DATABASE.md for the rationale.
 */
class BibleDatabaseManager {
  private bibleDb: SQLiteDatabase | null = null;
  private userDb: SQLiteDatabase | null = null;

  async open(): Promise<void> {
    if (this.bibleDb && this.userDb) return;

    this.bibleDb = await SQLite.openDatabase({
      name: 'bible.db',
      createFromLocation: '~bible.db', // pre-populated asset bundled at build time
      readOnly: true,
    });

    this.userDb = await SQLite.openDatabase({
      name: 'user.db',
      location: 'default',
    });

    await this.runUserSchema();
  }

  private async runUserSchema(): Promise<void> {
    if (!this.userDb) throw new Error('userDb not open');
    // User-data tables only. Bible text tables live in the read-only bible.db.
    const statements = [
      `CREATE TABLE IF NOT EXISTS bookmarks (
        id TEXT PRIMARY KEY, book_id TEXT NOT NULL, chapter_number INTEGER NOT NULL,
        verse_number INTEGER NOT NULL, verse_number_end INTEGER, note TEXT, created_at INTEGER NOT NULL
      );`,
      `CREATE INDEX IF NOT EXISTS idx_bookmarks_book ON bookmarks (book_id, chapter_number);`,
      `CREATE TABLE IF NOT EXISTS highlights (
        id TEXT PRIMARY KEY, book_id TEXT NOT NULL, chapter_number INTEGER NOT NULL,
        verse_number INTEGER NOT NULL, color TEXT NOT NULL, created_at INTEGER NOT NULL
      );`,
      `CREATE TABLE IF NOT EXISTS notes (
        id TEXT PRIMARY KEY, book_id TEXT NOT NULL, chapter_number INTEGER NOT NULL,
        verse_number INTEGER NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
      );`,
      `CREATE TABLE IF NOT EXISTS reading_history (
        book_id TEXT NOT NULL, chapter_number INTEGER NOT NULL, last_verse_number INTEGER,
        read_at INTEGER NOT NULL, PRIMARY KEY (book_id, chapter_number)
      );`,
      `CREATE INDEX IF NOT EXISTS idx_history_read_at ON reading_history (read_at DESC);`,
      `CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);`,
    ];
    for (const sql of statements) {
      await this.userDb.executeSql(sql);
    }
  }

  getBibleDb(): SQLiteDatabase {
    if (!this.bibleDb) throw new Error('Bible database not open — call open() first (and ensure bible.db was bundled by build-database).');
    return this.bibleDb;
  }

  getUserDb(): SQLiteDatabase {
    if (!this.userDb) throw new Error('User database not open — call open() first.');
    return this.userDb;
  }

  async close(): Promise<void> {
    await this.bibleDb?.close();
    await this.userDb?.close();
    this.bibleDb = null;
    this.userDb = null;
  }
}

export const bibleDatabase = new BibleDatabaseManager();
