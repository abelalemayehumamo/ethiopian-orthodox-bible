import { bibleDatabase } from './BibleDatabase';
import { BookMeta, Chapter, Verse, SearchResult, Testament } from '@/types/bible';

/**
 * All read access to Bible text goes through this repository. Screens never
 * write raw SQL — this keeps query shape/optimization in one place and makes
 * it easy to unit test (see tests/unit/BibleRepository.test.ts).
 */
export class BibleRepository {
  async getBooks(testament?: Testament): Promise<BookMeta[]> {
    const db = bibleDatabase.getBibleDb();
    const sql = testament
      ? 'SELECT * FROM books WHERE testament = ? ORDER BY book_order ASC'
      : 'SELECT * FROM books ORDER BY book_order ASC';
    const params = testament ? [testament] : [];
    const [result] = await db.executeSql(sql, params);
    const books: BookMeta[] = [];
    for (let i = 0; i < result.rows.length; i++) {
      books.push(this.rowToBook(result.rows.item(i)));
    }
    return books;
  }

  async getBook(bookId: string): Promise<BookMeta | null> {
    const db = bibleDatabase.getBibleDb();
    const [result] = await db.executeSql('SELECT * FROM books WHERE id = ?', [bookId]);
    if (result.rows.length === 0) return null;
    return this.rowToBook(result.rows.item(0));
  }

  async getChapters(bookId: string): Promise<Chapter[]> {
    const db = bibleDatabase.getBibleDb();
    const [result] = await db.executeSql(
      'SELECT * FROM chapters WHERE book_id = ? ORDER BY chapter_number ASC',
      [bookId],
    );
    const chapters: Chapter[] = [];
    for (let i = 0; i < result.rows.length; i++) {
      const row = result.rows.item(i);
      chapters.push({ bookId: row.book_id, chapterNumber: row.chapter_number, verseCount: row.verse_count });
    }
    return chapters;
  }

  async getVerses(bookId: string, chapterNumber: number): Promise<Verse[]> {
    const db = bibleDatabase.getBibleDb();
    const [result] = await db.executeSql(
      'SELECT * FROM verses WHERE book_id = ? AND chapter_number = ? ORDER BY verse_number ASC',
      [bookId, chapterNumber],
    );
    const verses: Verse[] = [];
    for (let i = 0; i < result.rows.length; i++) {
      const row = result.rows.item(i);
      verses.push({
        bookId: row.book_id,
        chapterNumber: row.chapter_number,
        verseNumber: row.verse_number,
        text: row.text,
      });
    }
    return verses;
  }

  /**
   * Plain indexed LIKE search (see schema.sql for why this replaced FTS5).
   * Escapes SQLite LIKE wildcards (% and _) in the user's input so a verse
   * containing a literal "%" or "_" can't be mistaken for a wildcard, and
   * wraps the cleaned query in % on both sides for substring matching.
   */
  async search(query: string, opts?: { bookId?: string; testament?: Testament; limit?: number }): Promise<SearchResult[]> {
    const db = bibleDatabase.getBibleDb();
    const cleaned = query.trim();
    if (!cleaned) return [];
    const escaped = cleaned.replace(/[%_\\]/g, (ch) => `\\${ch}`);
    const likePattern = `%${escaped}%`;
    const limit = opts?.limit ?? 100;

    let sql = `
      SELECT v.book_id, v.chapter_number, v.verse_number, v.text, b.name_am AS book_name_am
      FROM verses v
      JOIN books b ON b.id = v.book_id
      WHERE v.text LIKE ? ESCAPE '\\'`;
    const params: (string | number)[] = [likePattern];

    if (opts?.bookId) {
      sql += ' AND v.book_id = ?';
      params.push(opts.bookId);
    }
    if (opts?.testament) {
      sql += ' AND b.testament = ?';
      params.push(opts.testament);
    }
    sql += ' LIMIT ?';
    params.push(limit);

    const [result] = await db.executeSql(sql, params);
    const results: SearchResult[] = [];
    for (let i = 0; i < result.rows.length; i++) {
      const row = result.rows.item(i);
      results.push({
        bookId: row.book_id,
        bookNameAm: row.book_name_am,
        chapterNumber: row.chapter_number,
        verseNumber: row.verse_number,
        text: row.text,
        snippet: this.buildSnippet(row.text, cleaned),
      });
    }
    return results;
  }

  private buildSnippet(text: string, query: string): string {
    const idx = text.indexOf(query);
    if (idx === -1) return text.length > 120 ? text.slice(0, 120) + '…' : text;
    const start = Math.max(0, idx - 40);
    const end = Math.min(text.length, idx + query.length + 40);
    return (start > 0 ? '…' : '') + text.slice(start, end) + (end < text.length ? '…' : '');
  }

  private rowToBook(row: any): BookMeta {
    return {
      id: row.id,
      testament: row.testament,
      order: row.book_order,
      nameAm: row.name_am,
      nameEn: row.name_en,
      chapterCount: row.chapter_count,
      verified: !!row.verified,
    };
  }
}

export const bibleRepository = new BibleRepository();
