-- Ethiopian Orthodox Bible — SQLite schema
-- Every table is documented inline. Run through scripts/build-database to produce
-- the bundled bible.db shipped inside the Android app assets.

PRAGMA foreign_keys = ON;

-- Schema versioning: bumped on every structural change; app checks this at
-- startup and runs migrations in src/database/migrations/ if the bundled
-- schema is newer than the installed one.
CREATE TABLE IF NOT EXISTS schema_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
INSERT OR IGNORE INTO schema_meta (key, value) VALUES ('schema_version', '1');

-- One row per canonical book (up to 81). Chapter counts are NULL and
-- verified=0 until confirmed against an authoritative source — see
-- src/data/canon.json for the current state.
CREATE TABLE IF NOT EXISTS books (
  id             TEXT PRIMARY KEY,      -- short stable id, e.g. 'gen'
  testament      TEXT NOT NULL CHECK (testament IN ('old','new')),
  book_order     INTEGER NOT NULL,      -- position in the full 81-book sequence
  name_am        TEXT NOT NULL,         -- Amharic display name
  name_en        TEXT NOT NULL,         -- English reference name (debug/admin only)
  chapter_count  INTEGER,               -- NULL until verified
  verified       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_books_testament_order ON books (testament, book_order);

-- One row per chapter of a book. verse_count is derived at import time from
-- the actual imported verses (never hard-coded), so it can never drift from
-- the real data.
CREATE TABLE IF NOT EXISTS chapters (
  book_id        TEXT NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  chapter_number INTEGER NOT NULL,
  verse_count    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (book_id, chapter_number)
);

-- The actual Bible text. One row per verse. Left empty (zero rows) until an
-- authorized dataset is imported via scripts/import-bible.
CREATE TABLE IF NOT EXISTS verses (
  book_id        TEXT NOT NULL,
  chapter_number INTEGER NOT NULL,
  verse_number   INTEGER NOT NULL,
  text           TEXT NOT NULL,
  PRIMARY KEY (book_id, chapter_number, verse_number),
  FOREIGN KEY (book_id, chapter_number) REFERENCES chapters(book_id, chapter_number) ON DELETE CASCADE
);

-- Full-text search index over verse text (Amharic/Ethiopic Unicode is
-- stored as-is; FTS5's unicode61 tokenizer handles it at the codepoint
-- level, which is sufficient for substring/word search — see DATABASE.md
-- for why we did not attempt Ge'ez-specific stemming).
CREATE VIRTUAL TABLE IF NOT EXISTS verses_fts USING fts5(
  book_id UNINDEXED,
  chapter_number UNINDEXED,
  verse_number UNINDEXED,
  text,
  content='verses',
  content_rowid='rowid'
);

-- Keep verses_fts in sync automatically.
CREATE TRIGGER IF NOT EXISTS verses_ai AFTER INSERT ON verses BEGIN
  INSERT INTO verses_fts(rowid, book_id, chapter_number, verse_number, text)
  VALUES (new.rowid, new.book_id, new.chapter_number, new.verse_number, new.text);
END;
CREATE TRIGGER IF NOT EXISTS verses_ad AFTER DELETE ON verses BEGIN
  INSERT INTO verses_fts(verses_fts, rowid, book_id, chapter_number, verse_number, text)
  VALUES ('delete', old.rowid, old.book_id, old.chapter_number, old.verse_number, old.text);
END;
CREATE TRIGGER IF NOT EXISTS verses_au AFTER UPDATE ON verses BEGIN
  INSERT INTO verses_fts(verses_fts, rowid, book_id, chapter_number, verse_number, text)
  VALUES ('delete', old.rowid, old.book_id, old.chapter_number, old.verse_number, old.text);
  INSERT INTO verses_fts(rowid, book_id, chapter_number, verse_number, text)
  VALUES (new.rowid, new.book_id, new.chapter_number, new.verse_number, new.text);
END;

-- User data below this line lives in a SEPARATE user.db, not bible.db, so
-- that re-shipping an updated/corrected Bible text database never touches
-- the user's bookmarks/history/settings. See DATABASE.md.

CREATE TABLE IF NOT EXISTS bookmarks (
  id             TEXT PRIMARY KEY,
  book_id        TEXT NOT NULL,
  chapter_number INTEGER NOT NULL,
  verse_number   INTEGER NOT NULL,
  verse_number_end INTEGER,
  note           TEXT,
  created_at     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bookmarks_book ON bookmarks (book_id, chapter_number);

CREATE TABLE IF NOT EXISTS highlights (
  id             TEXT PRIMARY KEY,
  book_id        TEXT NOT NULL,
  chapter_number INTEGER NOT NULL,
  verse_number   INTEGER NOT NULL,
  color          TEXT NOT NULL,
  created_at     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_highlights_book ON highlights (book_id, chapter_number);

CREATE TABLE IF NOT EXISTS notes (
  id             TEXT PRIMARY KEY,
  book_id        TEXT NOT NULL,
  chapter_number INTEGER NOT NULL,
  verse_number   INTEGER NOT NULL,
  body           TEXT NOT NULL,
  created_at     INTEGER NOT NULL,
  updated_at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reading_history (
  book_id          TEXT NOT NULL,
  chapter_number   INTEGER NOT NULL,
  last_verse_number INTEGER,
  read_at          INTEGER NOT NULL,
  PRIMARY KEY (book_id, chapter_number)
);
CREATE INDEX IF NOT EXISTS idx_history_read_at ON reading_history (read_at DESC);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
