import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { RootStackParamList } from './types';
import { useAppTheme } from '@/context/ThemeContext';

import HomeScreen from '@/screens/HomeScreen';
import TestamentScreen from '@/screens/TestamentScreen';
import BookListScreen from '@/screens/BookListScreen';
import ChapterGridScreen from '@/screens/ChapterGridScreen';
import ReaderScreen from '@/screens/ReaderScreen';
import SearchScreen from '@/screens/SearchScreen';
import BookmarksScreen from '@/screens/BookmarksScreen';
import HistoryScreen from '@/screens/HistoryScreen';
import SettingsScreen from '@/screens/SettingsScreen';
import AboutScreen from '@/screens/AboutScreen';
import DrawerContent from '@/components/NavigationDrawer';
import Header from '@/components/Header';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Drawer = createDrawerNavigator();

function MainStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        header: (props) => <Header {...props} />,
      }}
    >
      <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'መነሻ' }} />
      <Stack.Screen name="Testament" component={TestamentScreen} options={{ title: 'ኪዳን' }} />
      <Stack.Screen name="BookList" component={BookListScreen} options={{ title: 'መጻሕፍት' }} />
      <Stack.Screen name="ChapterGrid" component={ChapterGridScreen} options={{ title: 'ምዕራፎች' }} />
      <Stack.Screen name="Reader" component={ReaderScreen} options={{ title: 'ንባብ' }} />
      <Stack.Screen name="Search" component={SearchScreen} options={{ title: 'ፍለጋ' }} />
      <Stack.Screen name="Bookmarks" component={BookmarksScreen} options={{ title: 'የተቀመጡ' }} />
      <Stack.Screen name="History" component={HistoryScreen} options={{ title: 'የቅርብ ጊዜ ንባብ' }} />
      <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'ቅንብሮች' }} />
      <Stack.Screen name="About" component={AboutScreen} options={{ title: 'ስለ መተግበሪያው' }} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { theme } = useAppTheme();
  return (
    <NavigationContainer
      theme={{
        dark: theme.mode === 'dark',
        colors: {
          primary: theme.accent,
          background: theme.background,
          card: theme.surface,
          text: theme.textPrimary,
          border: theme.border,
          notification: theme.accent,
        },
      }}
    >
      <Drawer.Navigator
        drawerContent={(props) => <DrawerContent {...props} />}
        screenOptions={{ headerShown: false, drawerType: 'front' }}
      >
        <Drawer.Screen name="Main" component={MainStack} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
