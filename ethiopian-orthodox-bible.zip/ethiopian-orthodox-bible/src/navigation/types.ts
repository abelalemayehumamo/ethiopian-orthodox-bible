export type RootStackParamList = {
  Home: undefined;
  Testament: { testament: 'old' | 'new' };
  BookList: { testament: 'old' | 'new' };
  ChapterGrid: { bookId: string };
  Reader: { bookId: string; chapterNumber: number; verseNumber?: number };
  Search: undefined;
  Bookmarks: undefined;
  History: undefined;
  Settings: undefined;
  About: undefined;
};

export type DrawerParamList = {
  Main: undefined;
};
