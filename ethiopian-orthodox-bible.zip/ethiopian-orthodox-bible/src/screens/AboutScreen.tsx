import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useAppTheme } from '@/context/ThemeContext';
import { spacing } from '@/theme/theme';

export default function AboutScreen() {
  const { theme } = useAppTheme();
  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={{ padding: spacing.lg }}>
      <Text style={[styles.title, { color: theme.textPrimary }]}>ስለ መተግበሪያው</Text>
      <Text style={[styles.body, { color: theme.textSecondary }]}>
        ይህ መተግበሪያ የኢትዮጵያ ኦርቶዶክስ ተዋሕዶ ቤተ ክርስቲያንን የመጽሐፍ ቅዱስ ቀኖና ለማቅረብ የተዘጋጀ ነው። የመጽሐፍ ቅዱሱ ጽሑፍ ምንጭ እና የፈቃድ
        መረጃ በ LICENSES.md ውስጥ ተገልጿል። ይህ መተግበሪያ በኢትዮጵያ ኦርቶዶክስ ተዋሕዶ ቤተ ክርስቲያን በይፋ የተደገፈ አይደለም።
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 22, fontWeight: '800', marginBottom: spacing.md },
  body: { fontSize: 15, lineHeight: 22 },
});
