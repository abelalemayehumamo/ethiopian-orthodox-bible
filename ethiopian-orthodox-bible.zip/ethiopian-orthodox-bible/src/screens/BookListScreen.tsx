import React, { useEffect, useState } from 'react';
import { FlatList, ActivityIndicator, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { bibleRepository } from '@/database/BibleRepository';
import { BookMeta } from '@/types/bible';
import BookCard from '@/components/BookCard';

type Props = NativeStackScreenProps<RootStackParamList, 'BookList'>;

export default function BookListScreen({ route, navigation }: Props) {
  const { theme } = useAppTheme();
  const { testament } = route.params;
  const [books, setBooks] = useState<BookMeta[] | null>(null);

  useEffect(() => {
    bibleRepository.getBooks(testament).then(setBooks);
  }, [testament]);

  if (!books) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.background }}>
        <ActivityIndicator color={theme.accent} />
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: theme.background }}
      contentContainerStyle={{ paddingVertical: 12 }}
      data={books}
      keyExtractor={(b) => b.id}
      renderItem={({ item }) => (
        <BookCard book={item} onPress={() => navigation.navigate('ChapterGrid', { bookId: item.id })} />
      )}
    />
  );
}
