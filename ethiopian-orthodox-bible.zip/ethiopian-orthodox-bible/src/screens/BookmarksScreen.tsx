import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { bookmarkService } from '@/services/BookmarkService';
import { bibleRepository } from '@/database/BibleRepository';
import { Bookmark } from '@/types/bible';
import { spacing, radius } from '@/theme/theme';

type Props = NativeStackScreenProps<RootStackParamList, 'Bookmarks'>;
type Row = Bookmark & { bookNameAm: string };

export default function BookmarksScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [rows, setRows] = useState<Row[]>([]);

  const load = useCallback(async () => {
    const list = await bookmarkService.list();
    const withNames = await Promise.all(
      list.map(async (bm) => {
        const book = await bibleRepository.getBook(bm.bookId);
        return { ...bm, bookNameAm: book?.nameAm ?? bm.bookId };
      }),
    );
    setRows(withNames);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const remove = async (id: string) => {
    await bookmarkService.remove(id);
    load();
  };

  if (rows.length === 0) {
    return (
      <View style={[styles.empty, { backgroundColor: theme.background }]}>
        <Text style={{ color: theme.textSecondary }}>ምንም የተቀመጠ ጥቅስ የለም</Text>
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: theme.background }}
      data={rows}
      keyExtractor={(r) => r.id}
      contentContainerStyle={{ padding: spacing.md }}
      renderItem={({ item }) => (
        <View style={[styles.card, { borderColor: theme.border, backgroundColor: theme.surfaceGlass }]}>
          <TouchableOpacity
            style={{ flex: 1 }}
            onPress={() => navigation.navigate('Reader', { bookId: item.bookId, chapterNumber: item.chapterNumber, verseNumber: item.verseNumber })}
          >
            <Text style={{ color: theme.textPrimary, fontWeight: '600' }}>
              {item.bookNameAm} {item.chapterNumber}:{item.verseNumber}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => remove(item.id)}>
            <Text style={{ color: theme.accent }}>ሰርዝ</Text>
          </TouchableOpacity>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  card: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: spacing.md, borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.md, marginBottom: spacing.sm,
  },
});
