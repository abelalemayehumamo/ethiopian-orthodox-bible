import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { bibleRepository } from '@/database/BibleRepository';
import { Chapter, BookMeta } from '@/types/bible';
import ChapterCell from '@/components/ChapterCell';
import { spacing } from '@/theme/theme';

type Props = NativeStackScreenProps<RootStackParamList, 'ChapterGrid'>;

export default function ChapterGridScreen({ route, navigation }: Props) {
  const { theme } = useAppTheme();
  const { bookId } = route.params;
  const [chapters, setChapters] = useState<Chapter[] | null>(null);
  const [book, setBook] = useState<BookMeta | null>(null);

  useEffect(() => {
    bibleRepository.getBook(bookId).then(setBook);
    bibleRepository.getChapters(bookId).then(setChapters);
  }, [bookId]);

  if (!chapters || !book) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.background }}>
        <ActivityIndicator color={theme.accent} />
      </View>
    );
  }

  if (chapters.length === 0) {
    return (
      <View style={[styles.empty, { backgroundColor: theme.background }]}>
        <Text style={{ color: theme.textSecondary, textAlign: 'center' }}>
          ለ{book.nameAm} ገና ምንም ጽሑፍ አልገባም። ትክክለኛ የመጽሐፍ ቅዱስ ውሂብ ካስገቡ በኋላ ምዕራፎች እዚህ ይታያሉ።
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: theme.background }}
      contentContainerStyle={styles.grid}
      data={chapters}
      numColumns={5}
      keyExtractor={(c) => String(c.chapterNumber)}
      renderItem={({ item }) => (
        <ChapterCell
          number={item.chapterNumber}
          onPress={() => navigation.navigate('Reader', { bookId, chapterNumber: item.chapterNumber })}
        />
      )}
    />
  );
}

const styles = StyleSheet.create({
  grid: { padding: spacing.md, alignItems: 'center' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },
});
