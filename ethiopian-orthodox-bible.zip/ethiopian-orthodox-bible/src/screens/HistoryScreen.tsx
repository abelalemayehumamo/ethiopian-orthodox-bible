import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { historyService } from '@/services/HistoryService';
import { bibleRepository } from '@/database/BibleRepository';
import { HistoryEntry } from '@/types/bible';
import { spacing, radius } from '@/theme/theme';

type Props = NativeStackScreenProps<RootStackParamList, 'History'>;
type Row = HistoryEntry & { bookNameAm: string };

export default function HistoryScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [rows, setRows] = useState<Row[]>([]);

  const load = useCallback(async () => {
    const list = await historyService.recent(50);
    const withNames = await Promise.all(
      list.map(async (h) => {
        const book = await bibleRepository.getBook(h.bookId);
        return { ...h, bookNameAm: book?.nameAm ?? h.bookId };
      }),
    );
    setRows(withNames);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  if (rows.length === 0) {
    return (
      <View style={[styles.empty, { backgroundColor: theme.background }]}>
        <Text style={{ color: theme.textSecondary }}>ምንም የንባብ ታሪክ የለም</Text>
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: theme.background }}
      data={rows}
      keyExtractor={(r) => `${r.bookId}-${r.chapterNumber}`}
      contentContainerStyle={{ padding: spacing.md }}
      renderItem={({ item }) => (
        <TouchableOpacity
          style={[styles.card, { borderColor: theme.border, backgroundColor: theme.surfaceGlass }]}
          onPress={() => navigation.navigate('Reader', { bookId: item.bookId, chapterNumber: item.chapterNumber })}
        >
          <Text style={{ color: theme.textPrimary, fontWeight: '600' }}>
            {item.bookNameAm} — ምዕራፍ {item.chapterNumber}
          </Text>
          <Text style={{ color: theme.textSecondary, fontSize: 12, marginTop: 4 }}>
            {new Date(item.readAt).toLocaleString('am-ET')}
          </Text>
        </TouchableOpacity>
      )}
    />
  );
}

const styles = StyleSheet.create({
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  card: { padding: spacing.md, borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.md, marginBottom: spacing.sm },
});
