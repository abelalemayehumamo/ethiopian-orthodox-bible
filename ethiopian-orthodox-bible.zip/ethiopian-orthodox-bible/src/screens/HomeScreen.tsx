import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Animated } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { spacing, radius } from '@/theme/theme';
import { historyService } from '@/services/HistoryService';
import { bibleRepository } from '@/database/BibleRepository';
import { HistoryEntry } from '@/types/bible';

type Props = NativeStackScreenProps<RootStackParamList, 'Home'>;

export default function HomeScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [lastRead, setLastRead] = useState<HistoryEntry | null>(null);
  const [lastReadBookName, setLastReadBookName] = useState<string>('');
  const fade = React.useRef(new Animated.Value(0)).current;

  useFocusEffect(
    useCallback(() => {
      historyService.last().then(async (entry) => {
        setLastRead(entry);
        if (entry) {
          const book = await bibleRepository.getBook(entry.bookId);
          setLastReadBookName(book?.nameAm ?? entry.bookId);
        }
      });
    }, []),
  );

  useEffect(() => {
    Animated.timing(fade, { toValue: 1, duration: 450, useNativeDriver: true }).start();
  }, [fade]);

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
      <Animated.View style={{ opacity: fade }}>
        <Text style={[styles.welcome, { color: theme.accent }]}>እንኳን ደህና መጡ</Text>
        <Text style={[styles.appName, { color: theme.textPrimary }]}>መጽሐፍ ቅዱስ</Text>

        {lastRead && (
          <TouchableOpacity
            style={[styles.card, { backgroundColor: theme.surfaceGlass, borderColor: theme.border }]}
            onPress={() =>
              navigation.navigate('Reader', {
                bookId: lastRead.bookId,
                chapterNumber: lastRead.chapterNumber,
                verseNumber: lastRead.lastVerseNumber ?? undefined,
              })
            }
          >
            <Text style={[styles.cardLabel, { color: theme.textSecondary }]}>ንባብዎን ይቀጥሉ</Text>
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>
              {lastReadBookName} — ምዕራፍ {lastRead.chapterNumber}
            </Text>
          </TouchableOpacity>
        )}

        <View style={styles.row}>
          <TouchableOpacity
            style={[styles.bigButton, { backgroundColor: theme.accent }]}
            onPress={() => navigation.navigate('BookList', { testament: 'old' })}
          >
            <Text style={styles.bigButtonText}>ብሉይ ኪዳን</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.bigButton, { backgroundColor: theme.accent }]}
            onPress={() => navigation.navigate('BookList', { testament: 'new' })}
          >
            <Text style={styles.bigButtonText}>ሐዲስ ኪዳን</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.shortcutRow}>
          <ShortcutButton label="ፍለጋ" onPress={() => navigation.navigate('Search')} />
          <ShortcutButton label="የተቀመጡ" onPress={() => navigation.navigate('Bookmarks')} />
          <ShortcutButton label="የቅርብ ጊዜ" onPress={() => navigation.navigate('History')} />
        </View>
      </Animated.View>
    </ScrollView>
  );
}

function ShortcutButton({ label, onPress }: { label: string; onPress: () => void }) {
  const { theme } = useAppTheme();
  return (
    <TouchableOpacity
      style={[styles.shortcut, { backgroundColor: theme.surfaceGlass, borderColor: theme.border }]}
      onPress={onPress}
    >
      <Text style={{ color: theme.textPrimary }}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.lg, paddingBottom: spacing.xl },
  welcome: { fontSize: 16, fontWeight: '600' },
  appName: { fontSize: 30, fontWeight: '800', marginBottom: spacing.lg },
  card: { borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.lg },
  cardLabel: { fontSize: 13, marginBottom: 4 },
  cardTitle: { fontSize: 18, fontWeight: '700' },
  row: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.lg },
  bigButton: { flex: 1, borderRadius: radius.lg, paddingVertical: spacing.lg, alignItems: 'center' },
  bigButtonText: { color: '#fff', fontSize: 17, fontWeight: '700' },
  shortcutRow: { flexDirection: 'row', gap: spacing.sm },
  shortcut: { flex: 1, borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.md, padding: spacing.md, alignItems: 'center' },
});
