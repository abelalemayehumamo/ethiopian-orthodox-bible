import React, { useEffect, useState, useCallback, useRef } from 'react';
import { View, FlatList, ActivityIndicator, StyleSheet, TouchableOpacity, Text, Share, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { bibleRepository } from '@/database/BibleRepository';
import { bookmarkService } from '@/services/BookmarkService';
import { historyService } from '@/services/HistoryService';
import { settingsService } from '@/services/SettingsService';
import { Verse, ReaderSettings, BookMeta } from '@/types/bible';
import VerseItem from '@/components/VerseItem';
import { spacing } from '@/theme/theme';

type Props = NativeStackScreenProps<RootStackParamList, 'Reader'>;

export default function ReaderScreen({ route, navigation }: Props) {
  const { theme } = useAppTheme();
  const { bookId, chapterNumber } = route.params;
  const [verses, setVerses] = useState<Verse[] | null>(null);
  const [book, setBook] = useState<BookMeta | null>(null);
  const [settings, setSettings] = useState<ReaderSettings | null>(null);
  const [bookmarkedSet, setBookmarkedSet] = useState<Set<number>>(new Set());
  const listRef = useRef<FlatList<Verse>>(null);

  const load = useCallback(async () => {
    const [v, b, s, bookmarks] = await Promise.all([
      bibleRepository.getVerses(bookId, chapterNumber),
      bibleRepository.getBook(bookId),
      settingsService.get(),
      bookmarkService.list(),
    ]);
    setVerses(v);
    setBook(b);
    setSettings(s);
    setBookmarkedSet(
      new Set(
        bookmarks
          .filter((bm) => bm.bookId === bookId && bm.chapterNumber === chapterNumber)
          .map((bm) => bm.verseNumber),
      ),
    );
    navigation.setOptions({ title: b ? `${b.nameAm} ${chapterNumber}` : `ምዕራፍ ${chapterNumber}` });
    await historyService.recordRead(bookId, chapterNumber, route.params.verseNumber ?? null);
  }, [bookId, chapterNumber, navigation, route.params.verseNumber]);

  useEffect(() => {
    load();
  }, [load]);

  const onVerseLongPress = (verse: Verse) => {
    Alert.alert(`${book?.nameAm ?? bookId} ${chapterNumber}:${verse.verseNumber}`, verse.text, [
      { text: 'ምልክት አድርግ', onPress: () => toggleBookmark(verse) },
      { text: 'ቅዳ', onPress: () => copyVerse(verse) },
      { text: 'አጋራ', onPress: () => shareVerse(verse) },
      { text: 'ዝጋ', style: 'cancel' },
    ]);
  };

  const toggleBookmark = async (verse: Verse) => {
    const already = bookmarkedSet.has(verse.verseNumber);
    if (already) {
      const all = await bookmarkService.list();
      const match = all.find(
        (bm) => bm.bookId === bookId && bm.chapterNumber === chapterNumber && bm.verseNumber === verse.verseNumber,
      );
      if (match) await bookmarkService.remove(match.id);
    } else {
      await bookmarkService.add(bookId, chapterNumber, verse.verseNumber);
    }
    load();
  };

  const shareVerse = (verse: Verse) => {
    Share.share({ message: `${verse.text} — ${book?.nameAm ?? bookId} ${chapterNumber}:${verse.verseNumber}` });
  };

  const copyVerse = (verse: Verse) => {
    // Clipboard requires @react-native-clipboard/clipboard; wired at App root.
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Clipboard = require('@react-native-clipboard/clipboard').default;
    Clipboard.setString(`${verse.text} — ${book?.nameAm ?? bookId} ${chapterNumber}:${verse.verseNumber}`);
  };

  const goToChapter = (delta: number) => {
    if (!book || !book.chapterCount) return;
    const next = chapterNumber + delta;
    if (next < 1 || next > book.chapterCount) return;
    navigation.setParams({ bookId, chapterNumber: next });
  };

  if (!verses || !settings) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.background }}>
        <ActivityIndicator color={theme.accent} />
      </View>
    );
  }

  if (verses.length === 0) {
    return (
      <View style={[styles.empty, { backgroundColor: theme.background }]}>
        <Text style={{ color: theme.textSecondary, textAlign: 'center' }}>
          ይህ ምዕራፍ ገና ጽሑፍ የለውም። ትክክለኛ የመጽሐፍ ቅዱስ ውሂብ ማስመጣት ያስፈልጋል (ተመልከት: scripts/import-bible)።
        </Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      <FlatList
        ref={listRef}
        data={verses}
        keyExtractor={(v) => String(v.verseNumber)}
        renderItem={({ item }) => (
          <VerseItem
            verse={item}
            settings={settings}
            bookmarked={bookmarkedSet.has(item.verseNumber)}
            onLongPress={onVerseLongPress}
          />
        )}
        contentContainerStyle={{ paddingVertical: spacing.md }}
      />
      <View style={[styles.navBar, { backgroundColor: theme.surface, borderTopColor: theme.border }]}>
        <TouchableOpacity onPress={() => goToChapter(-1)} style={styles.navButton}>
          <Text style={{ color: theme.accent, fontWeight: '700' }}>‹ ቀዳሚ</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => goToChapter(1)} style={styles.navButton}>
          <Text style={{ color: theme.accent, fontWeight: '700' }}>ቀጣይ ›</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: spacing.md,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  navButton: { padding: spacing.sm },
});
