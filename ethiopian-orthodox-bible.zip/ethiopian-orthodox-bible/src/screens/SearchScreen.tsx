import React, { useState } from 'react';
import { View, TextInput, FlatList, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { bibleRepository } from '@/database/BibleRepository';
import { SearchResult } from '@/types/bible';
import { spacing, radius } from '@/theme/theme';

type Props = NativeStackScreenProps<RootStackParamList, 'Search'>;

export default function SearchScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);

  const runSearch = async (text: string) => {
    setQuery(text);
    if (text.trim().length < 2) {
      setResults([]);
      return;
    }
    setLoading(true);
    try {
      const r = await bibleRepository.search(text);
      setResults(r);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      <TextInput
        value={query}
        onChangeText={runSearch}
        placeholder="በመጽሐፍ ቅዱስ ውስጥ ይፈልጉ..."
        placeholderTextColor={theme.textSecondary}
        style={[styles.input, { color: theme.textPrimary, borderColor: theme.border, backgroundColor: theme.surface }]}
      />
      {loading && <ActivityIndicator style={{ marginTop: spacing.md }} color={theme.accent} />}
      <FlatList
        data={results}
        keyExtractor={(r) => `${r.bookId}-${r.chapterNumber}-${r.verseNumber}`}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.result, { borderColor: theme.border, backgroundColor: theme.surfaceGlass }]}
            onPress={() =>
              navigation.navigate('Reader', { bookId: item.bookId, chapterNumber: item.chapterNumber, verseNumber: item.verseNumber })
            }
          >
            <Text style={{ color: theme.accent, fontWeight: '700', marginBottom: 4 }}>
              {item.bookNameAm} {item.chapterNumber}:{item.verseNumber}
            </Text>
            <Text style={{ color: theme.textPrimary }}>{item.snippet}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          !loading && query.length >= 2 ? (
            <Text style={{ color: theme.textSecondary, textAlign: 'center', marginTop: spacing.lg }}>ምንም ውጤት አልተገኘም</Text>
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  input: { margin: spacing.md, padding: spacing.md, borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.md, fontSize: 16 },
  result: { marginHorizontal: spacing.md, marginBottom: spacing.sm, padding: spacing.md, borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.md },
});
