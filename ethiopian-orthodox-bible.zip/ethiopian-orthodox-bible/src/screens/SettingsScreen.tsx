import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { useAppTheme } from '@/context/ThemeContext';
import { settingsService } from '@/services/SettingsService';
import { ReaderSettings, ThemeMode } from '@/types/bible';
import SettingRow from '@/components/SettingRow';
import { spacing } from '@/theme/theme';

export default function SettingsScreen() {
  const { theme, mode, setMode } = useAppTheme();
  const [settings, setSettings] = useState<ReaderSettings | null>(null);

  useEffect(() => {
    settingsService.get().then(setSettings);
  }, []);

  const updateFontSize = async (delta: number) => {
    if (!settings) return;
    const next = Math.min(28, Math.max(14, settings.fontSizeSp + delta));
    setSettings({ ...settings, fontSizeSp: next });
    await settingsService.set('fontSizeSp', next);
  };

  const updateLineHeight = async (delta: number) => {
    if (!settings) return;
    const next = Math.min(2.2, Math.max(1.2, +(settings.lineHeightMultiplier + delta).toFixed(1)));
    setSettings({ ...settings, lineHeightMultiplier: next });
    await settingsService.set('lineHeightMultiplier', next);
  };

  if (!settings) return null;

  const modes: { key: ThemeMode; label: string }[] = [
    { key: 'light', label: 'ብርሃን' },
    { key: 'dark', label: 'ጨለማ' },
    { key: 'system', label: 'ራስ-ሰር' },
  ];

  return (
    <ScrollView style={{ backgroundColor: theme.background }}>
      <SettingRow label="የፊደል መጠን">
        <View style={styles.stepper}>
          <StepButton label="－" onPress={() => updateFontSize(-1)} />
          <Text style={{ color: theme.textPrimary, marginHorizontal: spacing.sm }}>{settings.fontSizeSp}</Text>
          <StepButton label="＋" onPress={() => updateFontSize(1)} />
        </View>
      </SettingRow>
      <SettingRow label="የመስመር ርቀት">
        <View style={styles.stepper}>
          <StepButton label="－" onPress={() => updateLineHeight(-0.1)} />
          <Text style={{ color: theme.textPrimary, marginHorizontal: spacing.sm }}>{settings.lineHeightMultiplier.toFixed(1)}</Text>
          <StepButton label="＋" onPress={() => updateLineHeight(0.1)} />
        </View>
      </SettingRow>
      <SettingRow label="ገጽታ">
        <View style={styles.stepper}>
          {modes.map((m) => (
            <TouchableOpacity
              key={m.key}
              onPress={() => setMode(m.key)}
              style={[
                styles.modeButton,
                { borderColor: theme.border, backgroundColor: mode === m.key ? theme.accent : 'transparent' },
              ]}
            >
              <Text style={{ color: mode === m.key ? '#fff' : theme.textPrimary }}>{m.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </SettingRow>
    </ScrollView>
  );
}

function StepButton({ label, onPress }: { label: string; onPress: () => void }) {
  const { theme } = useAppTheme();
  return (
    <TouchableOpacity onPress={onPress} style={[styles.step, { borderColor: theme.border }]}>
      <Text style={{ color: theme.textPrimary, fontSize: 18 }}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  stepper: { flexDirection: 'row', alignItems: 'center' },
  step: { width: 32, height: 32, borderWidth: StyleSheet.hairlineWidth, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  modeButton: { paddingHorizontal: spacing.sm, paddingVertical: 6, borderWidth: StyleSheet.hairlineWidth, borderRadius: 8, marginLeft: spacing.xs },
});
