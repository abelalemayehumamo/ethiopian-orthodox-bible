import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { useAppTheme } from '@/context/ThemeContext';
import { spacing, radius } from '@/theme/theme';

type Props = NativeStackScreenProps<RootStackParamList, 'Testament'>;

// Simple landing screen when a testament is opened generically (from a deep
// link, for instance); normal navigation goes straight to BookList.
export default function TestamentScreen({ route, navigation }: Props) {
  const { theme } = useAppTheme();
  const { testament } = route.params;
  const title = testament === 'old' ? 'ብሉይ ኪዳን' : 'ሐዲስ ኪዳን';

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <Text style={[styles.title, { color: theme.textPrimary }]}>{title}</Text>
      <TouchableOpacity
        style={[styles.button, { backgroundColor: theme.accent }]}
        onPress={() => navigation.navigate('BookList', { testament })}
      >
        <Text style={styles.buttonText}>መጻሕፍትን ይመልከቱ</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.lg, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 24, fontWeight: '800', marginBottom: spacing.lg },
  button: { borderRadius: radius.lg, paddingVertical: spacing.md, paddingHorizontal: spacing.xl },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
