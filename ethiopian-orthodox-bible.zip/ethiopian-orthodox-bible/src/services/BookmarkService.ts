import { bibleDatabase } from '@/database/BibleDatabase';
import { Bookmark } from '@/types/bible';

function genId(): string {
  return `bm_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export class BookmarkService {
  async add(bookId: string, chapterNumber: number, verseNumber: number, verseNumberEnd?: number, note?: string): Promise<Bookmark> {
    const db = bibleDatabase.getUserDb();
    const bookmark: Bookmark = {
      id: genId(),
      bookId,
      chapterNumber,
      verseNumber,
      verseNumberEnd,
      note,
      createdAt: Date.now(),
    };
    await db.executeSql(
      `INSERT INTO bookmarks (id, book_id, chapter_number, verse_number, verse_number_end, note, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [bookmark.id, bookId, chapterNumber, verseNumber, verseNumberEnd ?? null, note ?? null, bookmark.createdAt],
    );
    return bookmark;
  }

  async remove(id: string): Promise<void> {
    const db = bibleDatabase.getUserDb();
    await db.executeSql('DELETE FROM bookmarks WHERE id = ?', [id]);
  }

  async list(): Promise<Bookmark[]> {
    const db = bibleDatabase.getUserDb();
    const [result] = await db.executeSql('SELECT * FROM bookmarks ORDER BY created_at DESC');
    const items: Bookmark[] = [];
    for (let i = 0; i < result.rows.length; i++) {
      const row = result.rows.item(i);
      items.push({
        id: row.id,
        bookId: row.book_id,
        chapterNumber: row.chapter_number,
        verseNumber: row.verse_number,
        verseNumberEnd: row.verse_number_end ?? undefined,
        note: row.note ?? undefined,
        createdAt: row.created_at,
      });
    }
    return items;
  }

  async isBookmarked(bookId: string, chapterNumber: number, verseNumber: number): Promise<boolean> {
    const db = bibleDatabase.getUserDb();
    const [result] = await db.executeSql(
      'SELECT 1 FROM bookmarks WHERE book_id = ? AND chapter_number = ? AND verse_number = ? LIMIT 1',
      [bookId, chapterNumber, verseNumber],
    );
    return result.rows.length > 0;
  }
}

export const bookmarkService = new BookmarkService();
