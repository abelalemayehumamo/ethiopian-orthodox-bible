import { bibleDatabase } from '@/database/BibleDatabase';
import { HistoryEntry } from '@/types/bible';

export class HistoryService {
  async recordRead(bookId: string, chapterNumber: number, lastVerseNumber: number | null): Promise<void> {
    const db = bibleDatabase.getUserDb();
    await db.executeSql(
      `INSERT INTO reading_history (book_id, chapter_number, last_verse_number, read_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(book_id, chapter_number) DO UPDATE SET last_verse_number = excluded.last_verse_number, read_at = excluded.read_at`,
      [bookId, chapterNumber, lastVerseNumber, Date.now()],
    );
  }

  async recent(limit = 10): Promise<HistoryEntry[]> {
    const db = bibleDatabase.getUserDb();
    const [result] = await db.executeSql(
      'SELECT * FROM reading_history ORDER BY read_at DESC LIMIT ?',
      [limit],
    );
    const items: HistoryEntry[] = [];
    for (let i = 0; i < result.rows.length; i++) {
      const row = result.rows.item(i);
      items.push({
        bookId: row.book_id,
        chapterNumber: row.chapter_number,
        lastVerseNumber: row.last_verse_number,
        readAt: row.read_at,
      });
    }
    return items;
  }

  async last(): Promise<HistoryEntry | null> {
    const items = await this.recent(1);
    return items[0] ?? null;
  }
}

export const historyService = new HistoryService();
