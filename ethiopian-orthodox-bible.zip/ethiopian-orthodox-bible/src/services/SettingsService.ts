import { bibleDatabase } from '@/database/BibleDatabase';
import { ReaderSettings, ThemeMode } from '@/types/bible';

const DEFAULTS: ReaderSettings = {
  fontSizeSp: 18,
  lineHeightMultiplier: 1.6,
  themeMode: 'system',
};

export class SettingsService {
  async get(): Promise<ReaderSettings> {
    const db = bibleDatabase.getUserDb();
    const [result] = await db.executeSql('SELECT key, value FROM settings');
    const map: Record<string, string> = {};
    for (let i = 0; i < result.rows.length; i++) {
      const row = result.rows.item(i);
      map[row.key] = row.value;
    }
    return {
      fontSizeSp: map.fontSizeSp ? Number(map.fontSizeSp) : DEFAULTS.fontSizeSp,
      lineHeightMultiplier: map.lineHeightMultiplier ? Number(map.lineHeightMultiplier) : DEFAULTS.lineHeightMultiplier,
      themeMode: (map.themeMode as ThemeMode) ?? DEFAULTS.themeMode,
    };
  }

  async set<K extends keyof ReaderSettings>(key: K, value: ReaderSettings[K]): Promise<void> {
    const db = bibleDatabase.getUserDb();
    await db.executeSql(
      `INSERT INTO settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      [key, String(value)],
    );
  }
}

export const settingsService = new SettingsService();
