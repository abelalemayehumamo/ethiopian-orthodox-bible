// Original design language: deep burgundy + gold accents evoke Ethiopian
// Orthodox liturgical color, warm parchment for reading surfaces. No
// copyrighted artwork or church imagery is referenced anywhere in this file.
export const palette = {
  burgundy: '#5C1A24',
  burgundyDeep: '#3D0F16',
  gold: '#C9A24B',
  goldSoft: '#E4CE8F',
  parchmentLight: '#FBF6EC',
  parchmentDark: '#1C1613',
  green: '#1F4D3D',
  ink: '#241A15',
  inkLight: '#EDE3D2',
};

export interface AppTheme {
  mode: 'light' | 'dark';
  background: string;
  surface: string;
  surfaceGlass: string; // semi-transparent card background
  textPrimary: string;
  textSecondary: string;
  accent: string;
  border: string;
}

export const lightTheme: AppTheme = {
  mode: 'light',
  background: palette.parchmentLight,
  surface: '#FFFFFF',
  surfaceGlass: 'rgba(255,255,255,0.72)',
  textPrimary: palette.ink,
  textSecondary: '#6B5B4E',
  accent: palette.burgundy,
  border: 'rgba(92,26,36,0.15)',
};

export const darkTheme: AppTheme = {
  mode: 'dark',
  background: palette.parchmentDark,
  surface: '#241D18',
  surfaceGlass: 'rgba(36,29,24,0.72)',
  textPrimary: palette.inkLight,
  textSecondary: '#C3B39E',
  accent: palette.goldSoft,
  border: 'rgba(228,206,143,0.18)',
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };
export const radius = { sm: 8, md: 14, lg: 22, pill: 999 };
