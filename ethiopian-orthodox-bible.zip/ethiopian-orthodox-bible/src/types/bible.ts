export type Testament = 'old' | 'new';

export interface BookMeta {
  id: string; // stable short id, e.g. "gen", "mat"
  testament: Testament;
  order: number; // canonical order within the whole 81-book Bible
  nameAm: string; // Amharic display name
  nameEn: string; // English reference name (internal/debug use only, not shown by default)
  chapterCount: number | null; // null until verified data is imported
  verified: boolean; // whether chapterCount/text has been confirmed against an authoritative source
}

export interface Chapter {
  bookId: string;
  chapterNumber: number;
  verseCount: number;
}

export interface Verse {
  bookId: string;
  chapterNumber: number;
  verseNumber: number;
  text: string;
}

export interface Bookmark {
  id: string;
  bookId: string;
  chapterNumber: number;
  verseNumber: number;
  verseNumberEnd?: number; // for verse ranges
  createdAt: number; // epoch ms
  note?: string;
}

export interface Highlight {
  id: string;
  bookId: string;
  chapterNumber: number;
  verseNumber: number;
  color: string;
  createdAt: number;
}

export interface HistoryEntry {
  bookId: string;
  chapterNumber: number;
  lastVerseNumber: number | null;
  readAt: number; // epoch ms, most recent read updates this
}

export interface SearchResult {
  bookId: string;
  bookNameAm: string;
  chapterNumber: number;
  verseNumber: number;
  text: string;
  snippet: string;
}

export type ThemeMode = 'light' | 'dark' | 'system';

export interface ReaderSettings {
  fontSizeSp: number; // e.g. 16-28
  lineHeightMultiplier: number; // e.g. 1.3-2.0
  themeMode: ThemeMode;
}

export interface AppSettingsRow {
  key: string;
  value: string;
}
