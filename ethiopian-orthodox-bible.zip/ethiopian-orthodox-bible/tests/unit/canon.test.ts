import canon from '../../src/data/canon.json';

describe('canon.json integrity', () => {
  it('has no duplicate book ids', () => {
    const ids = canon.books.map((b: any) => b.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('every book has a testament of old or new', () => {
    for (const b of canon.books as any[]) {
      expect(['old', 'new']).toContain(b.testament);
    }
  });

  it('order values are unique within each testament', () => {
    for (const testament of ['old', 'new']) {
      const orders = (canon.books as any[]).filter((b) => b.testament === testament).map((b) => b.order);
      expect(new Set(orders).size).toBe(orders.length);
    }
  });

  it('flags unverified entries instead of silently asserting chapter counts', () => {
    const unverified = (canon.books as any[]).filter((b) => !b.verified);
    // As of this scaffold, several Ethiopian-canon-unique books are intentionally
    // unverified — this test documents that state rather than hiding it.
    expect(unverified.length).toBeGreaterThan(0);
  });
});
